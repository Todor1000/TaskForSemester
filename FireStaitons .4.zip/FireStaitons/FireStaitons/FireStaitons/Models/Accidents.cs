﻿namespace FireStaitons.Models
{
    public class Accidents
    {
        public int Id { get; set; }
        public string Location { get; set; }
        public string Type { get; set; }
    }
}
