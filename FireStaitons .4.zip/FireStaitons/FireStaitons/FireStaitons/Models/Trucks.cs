﻿namespace FireStaitons.Models
{
    public class Trucks
    {
    }
}
