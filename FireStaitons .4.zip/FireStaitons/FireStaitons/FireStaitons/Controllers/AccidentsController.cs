﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using FireStaitons.Data;
using FireStaitons.Models;

namespace FireStaitons.Controllers
{
    public class AccidentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccidentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Accidents
        public async Task<IActionResult> Index()
        {
            return View(await _context.Accidents.ToListAsync());
        }

        // GET: Accidents/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var accidents = await _context.Accidents
                .FirstOrDefaultAsync(m => m.Id == id);
            if (accidents == null)
            {
                return NotFound();
            }

            return View(accidents);
        }

        // GET: Accidents/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Accidents/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Location,Type")] Accidents accidents)
        {
            if (ModelState.IsValid)
            {
                _context.Add(accidents);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(accidents);
        }

        // GET: Accidents/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var accidents = await _context.Accidents.FindAsync(id);
            if (accidents == null)
            {
                return NotFound();
            }
            return View(accidents);
        }

        // POST: Accidents/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Location,Type")] Accidents accidents)
        {
            if (id != accidents.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(accidents);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AccidentsExists(accidents.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(accidents);
        }

        // GET: Accidents/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var accidents = await _context.Accidents
                .FirstOrDefaultAsync(m => m.Id == id);
            if (accidents == null)
            {
                return NotFound();
            }

            return View(accidents);
        }

        // POST: Accidents/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var accidents = await _context.Accidents.FindAsync(id);
            if (accidents != null)
            {
                _context.Accidents.Remove(accidents);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AccidentsExists(int id)
        {
            return _context.Accidents.Any(e => e.Id == id);
        }
    }
}
